package part1;
import java.util.*;
import java.io.*;

public class BSTAndSetsTest {

	private static long height (TreeSet<Item> tree) {
		long maxComp = 0;
		for (Item current : tree) {
			Item.resetCompCount();
			tree.contains(current);
			if (maxComp < Item.getCompCount()) {
				maxComp = Item.getCompCount();
				}
			}
		return maxComp-1;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BinarySearchTree<Item> bst = new BinarySearchTree<>();
		List<Item> dataSet = new LinkedList<>();
		HashSet<Item> hset = new HashSet<>();
		TreeSet<Item> tset = new TreeSet<>();
		
		Item test = new Item(5);
		Random ran = new Random();
        System.out.print("Please enter the size of the data set: ");
        try (Scanner keyboard = new Scanner(System.in)) {
            int size = keyboard.nextInt();
            int count = 0;
           	System.out.println("The current size is: "+ size);
           	while (bst.size() < size && hset.size() < size && tset.size() < size) {
           		Item candidate = new Item(ran.nextInt(size)); // add numbers between 1 and size in random order
            	count++;
            		
               	if (bst.add(candidate) && hset.add(candidate) && tset.add(candidate)) {
                   	dataSet.add(candidate);
               	}
            }
           	System.out.println("Height of BST is: "+ bst.height());
           	System.out.println("Number of Leaves in the BST is: "+ bst.leaves());
           	System.out.println("Height of TreeSet is: "+ height(tset));
            Item.resetCompCount();
            System.out.printf("Added %d elements from %d numbers.\n", size, count);
            System.out.println("");
            
            
            System.out.println("Searching for value: " + test.value());
            
       		bst.contains(test);
        	System.out.println("BST CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();

        	tset.contains(test);
        	System.out.println("TreeSet CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();

        	hset.contains(new Item(test.value()));
        	System.out.println("HashSet CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();
        	
        	int insertAndRemoveSize = bst.size() / 5;
        	Item it = new Item(0);
        	List<Item> removed = new LinkedList<>();
        	int l = 0;
        	for (int i = 0; i < 10; i++){
        		for (l = 0; l < insertAndRemoveSize; l++){
        			it = dataSet.get(l);
        			bst.remove(it);
        			tset.remove(it);
        			hset.remove(it);
        			removed.add(it);
        		}
        		for (l = 0; l < insertAndRemoveSize; l++){
        			it = removed.get(l);
        			bst.add(it);
        			tset.add(it);
        			hset.add(it);
        		}        	
        	}
        	Item.resetCompCount();
        	
        	
        	bst.contains(test);
        	System.out.println("BST CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();

        	tset.contains(test);
        	System.out.println("TreeSet CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();

        	hset.contains(new Item(test.value()));
        	System.out.println("HashSet CompCount after contains(): " + Item.getCompCount());
        	Item.resetCompCount();
        	
        	       	
        
        	//Serialization & Deserialization
        
            try { // serialize the object
            	System.out.println("Serializing the binary search tree...");
            	FileOutputStream fos = new FileOutputStream("BST.ser");
            	ObjectOutputStream oos = new ObjectOutputStream(fos);
            	oos.writeObject(bst);
            	oos.close();
            } catch (Exception e) {
            	e.printStackTrace();
            }
        
            try { // de-serialize the object
            	System.out.println("Deserializing tree...");
            	FileInputStream fis = new FileInputStream("BST.ser");
            	ObjectInputStream ois = new ObjectInputStream(fis);
            	BinarySearchTree<Item> dsTree = (BinarySearchTree<Item>) ois.readObject();
        		ois.close();
        		System.out.println("Deserialized tree: " + dsTree);
            } catch (Exception e) {
            	e.printStackTrace();
            }

        }
	}

}

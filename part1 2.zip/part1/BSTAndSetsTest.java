package part1;
import java.util.*;
import java.io.*;

public class BSTAndSetsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BinarySearchTree<Item> bst = new BinarySearchTree<>();
		List<Item> dataSet = new LinkedList<>();
		HashSet<Item> hset = new HashSet<>();
		TreeSet<Item> tset = new TreeSet<>();
		
		Random ran = new Random();
        System.out.print("Please enter the size of the data set: ");
        try (Scanner keyboard = new Scanner(System.in)) {
            int size = keyboard.nextInt();
            System.out.println("#teamBeeby");
            int count = 0;
           	System.out.println("The current size is: "+ size);
           	while (bst.size() < size && hset.size() < size && tset.size() < size) {
           		Item candidate = new Item(ran.nextInt(100000)); // add random numbers between 1 and 100000 in random order
            	count++;
            		
               	if (bst.add(candidate) && hset.add(candidate) && tset.add(candidate)) {
                   	dataSet.add(candidate);
               	}
            }
            System.out.println("CompCount after add(): " + Item.getCompCount());
            Item.resetCompCount();
            System.out.printf("Added %d elements from %d numbers.\n", size, count);
        
        System.out.print("Dataset:");
        for (Item l: dataSet){
        	System.out.print(" " + l);
        }
        System.out.print("\n");
        System.out.println(hset);
        System.out.println(tset);
        
        try { // serialize the object
        	FileOutputStream fos = new FileOutputStream("BST.ser");
        	ObjectOutputStream oos = new ObjectOutputStream(fos);
        	//bst.writeObject(oos);
        	oos.writeObject(bst);
        	oos.close();
        } catch (Exception e) {
        	e.printStackTrace();
        }
        try { // de-serialize the object
        	FileInputStream fis = new FileInputStream("BST.ser");
        	ObjectInputStream ois = new ObjectInputStream(fis);
        	BinarySearchTree<Item> copy = (BinarySearchTree<Item>) ois.readObject();
        	ois.close();
        	System.out.println(copy);
        } catch (Exception e) {
        	e.printStackTrace();
        }

        
        
        
        /*
        int errorCount = 0;
    	System.out.println("Testing contains() method:");
        for (Item d : dataSet) {
        	if (bst.contains((d.value()/2)*2)) { // tests for absence of number out of bounds
        		errorCount++;
        		System.out.printf("Error %d: contains(%d) returns true.\n", errorCount, (d.value()/2)*2);
        	}
        	if (hset.contains((d.value()*100000))) { 
        		errorCount++;
        		System.out.printf("Error %d: contains(%d) returns true.\n", errorCount, (d.value()/2)*2);
        	}
        	if (tset.contains((d.value()*100000))) { 
        		errorCount++;
        		System.out.printf("Error %d: contains(%d) returns true.\n", errorCount, (d.value()/2)*2);
        	}
    	}
    	System.out.println("CompCount after contains(): " + Item.getCompCount());
    	Item.resetCompCount();
    	for (Item d : dataSet) {       
    		if (!bst.contains(d)) {
    			errorCount++;
    			System.out.printf("Error %d: contains(%d) returns false.\n", errorCount, d);
    		}
    		if (!hset.contains(d)) {
    			errorCount++;
    			System.out.printf("Error %d: contains(%d) returns false.\n", errorCount, d);
    		}
    		if (!tset.contains(d)) {
    			errorCount++;
    			System.out.printf("Error %d: contains(%d) returns false.\n", errorCount, d);
    		}
    	}
    	System.out.println("CompCount after contains(): " + Item.getCompCount());
    	Item.resetCompCount();
        */
        }
	}

}

package part1;

import java.util.*;

public class BSTItemTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BinarySearchTree<Item> bst = new BinarySearchTree<>();
        List<Item> dataSet = new LinkedList<>();
        Random ran = new Random();
        System.out.print("Please enter the size of the data set: ");
        try (Scanner keyboard = new Scanner(System.in)) {
            int size = keyboard.nextInt();
            System.out.printf("The sizes for the sequential Item input then random Item input are "
            		+ "%d, %d, %d, %d,\n", 
            		size, size*10, size*100, size*1000);
            int multiplier = 1;
            int count = 0;
            for (int pass = 0; pass < 8; pass++){
            	if (pass != 0 && pass % 2 == 0){
            		multiplier *= 10;
            		size = 100*multiplier;
            	}
            	count = 0;
            	Item candidate;
            	System.out.println("The current pass is: " + pass + " and size is: "+ size);
            	while (bst.size() < size) {
            		if (pass % 2 == 0)
            			candidate = new Item(count + 1); // add numbers from 1 to size
            		else
            			candidate = new Item(ran.nextInt(size)); // add numbers from 1 to size in random order
            		count++;
            		
                	if (bst.add(candidate)) {
                    	dataSet.add(candidate);
                	}
            	}
            	System.out.println("CompCount after add(): " + Item.getCompCount());
            	Item.resetCompCount();
            	System.out.printf("Added %d elements from %d numbers.\n", size, count);
            	int errorCount = 0;
            	System.out.println("Testing contains() method:");
            	for (Item d : dataSet) {
                	if (pass > 7){
                		if (bst.contains((d.value()/2)*2)) { // even number tests for absence
                            errorCount++;
                            System.out.printf("Error %d: contains(%d) returns true.\n", errorCount, (d.value()/2)*2);
                        }
                	}
                	else 
                	{
                		if (!bst.contains(d)) {
                        	errorCount++;
                        	System.out.printf("Error %d: contains(%d) returns false.\n", errorCount, d);
                    	}
                	}
            	}
            	System.out.println("CompCount after contains(): " + Item.getCompCount());
            	Item.resetCompCount();
            	System.out.printf("Testing contents complete with %d errors ", errorCount);
            	System.out.println();
            	System.out.println("Testing enumerator throws an exception if tree is modified while in use.");
            	try {
                	for (Item i : bst) {
                    	bst.add(new Item(-1));
                	}
                	errorCount++;
            	}
            	catch (ConcurrentModificationException e) {}
            	System.out.println("Testing exception throwing complete.");
            	System.out.printf( "Errors now %d.\n", errorCount);
            	System.out.println();
            	bst.remove(new Item(-1));
            	if (bst.size() <= 25) {
                	int counter = 1;
                	System.out.println("Tree contents are:");
                	for (Item i : bst) {
                    	System.out.printf("Item number %d is: %d\n", counter++, i.value());
                	}
            	}
            
            	System.out.println("The height of the tree is " + bst.height());
            	Item.resetCompCount();
            	System.out.println("Removing tree contents:");
            	count = bst.size();
            	errorCount = 0;
            	for (Item d : dataSet) {
                	if (bst.remove(d)) {
                    	count--;
                    	if (count != bst.size()) {
                    		errorCount++;  // tree size was not updated
                    	}
                	}
                	else  { // d was not removed
                		errorCount++;
                	}
            	}
            	System.out.println("CompCount after remove(): " + Item.getCompCount());
            	Item.resetCompCount();
            	System.out.printf("%d items removed with %d errors.\n", size, errorCount);
            	System.out.printf("Tree size = %d\n", bst.size());
            	System.out.println("Any remaining contents listed below:");
            	for (Item i : bst) {
            		System.out.println(i);
            	}
            	System.out.println("Testing complete.... \n");
            	dataSet.clear();
            }
        	}
        }

}
